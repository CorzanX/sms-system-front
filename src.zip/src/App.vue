<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  components: {

  }
}
</script>

<style scoped>

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* 设置容器高度占满整个视口 */
}

</style>
